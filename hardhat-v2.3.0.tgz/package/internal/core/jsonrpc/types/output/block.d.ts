/// <reference types="node" />
import * as t from "io-ts";
export declare type RpcBlock = t.TypeOf<typeof rpcBlock>;
export declare const rpcBlock: t.TypeC<{
    transactions: t.ArrayC<t.Type<Buffer, Buffer, unknown>>;
    number: t.Type<import("bn.js") | null, import("bn.js") | null, unknown>;
    hash: t.Type<Buffer | null, Buffer | null, unknown>;
    parentHash: t.Type<Buffer, Buffer, unknown>;
    nonce: t.Type<Buffer | undefined, Buffer | undefined, unknown>;
    sha3Uncles: t.Type<Buffer, Buffer, unknown>;
    logsBloom: t.Type<Buffer, Buffer, unknown>;
    transactionsRoot: t.Type<Buffer, Buffer, unknown>;
    stateRoot: t.Type<Buffer, Buffer, unknown>;
    receiptsRoot: t.Type<Buffer, Buffer, unknown>;
    miner: t.Type<Buffer, Buffer, unknown>;
    difficulty: t.Type<import("bn.js"), import("bn.js"), unknown>;
    totalDifficulty: t.Type<import("bn.js"), import("bn.js"), unknown>;
    extraData: t.Type<Buffer, Buffer, unknown>;
    size: t.Type<import("bn.js"), import("bn.js"), unknown>;
    gasLimit: t.Type<import("bn.js"), import("bn.js"), unknown>;
    gasUsed: t.Type<import("bn.js"), import("bn.js"), unknown>;
    timestamp: t.Type<import("bn.js"), import("bn.js"), unknown>;
    uncles: t.ArrayC<t.Type<Buffer, Buffer, unknown>>;
    mixHash: t.Type<Buffer | undefined, Buffer | undefined, unknown>;
}>;
export declare type RpcBlockWithTransactions = t.TypeOf<typeof rpcBlockWithTransactions>;
export declare const rpcBlockWithTransactions: t.TypeC<{
    transactions: t.ArrayC<t.TypeC<{
        blockHash: t.Type<Buffer | null, Buffer | null, unknown>;
        blockNumber: t.Type<import("bn.js") | null, import("bn.js") | null, unknown>;
        from: t.Type<Buffer, Buffer, unknown>;
        gas: t.Type<import("bn.js"), import("bn.js"), unknown>;
        gasPrice: t.Type<import("bn.js"), import("bn.js"), unknown>;
        hash: t.Type<Buffer, Buffer, unknown>;
        input: t.Type<Buffer, Buffer, unknown>;
        nonce: t.Type<import("bn.js"), import("bn.js"), unknown>;
        to: t.Type<Buffer | null | undefined, Buffer | null | undefined, unknown>;
        transactionIndex: t.Type<import("bn.js") | null, import("bn.js") | null, unknown>;
        value: t.Type<import("bn.js"), import("bn.js"), unknown>;
        v: t.Type<import("bn.js"), import("bn.js"), unknown>;
        r: t.Type<import("bn.js"), import("bn.js"), unknown>;
        s: t.Type<import("bn.js"), import("bn.js"), unknown>;
        type: t.Type<import("bn.js") | undefined, import("bn.js") | undefined, unknown>;
        chainId: t.Type<import("bn.js") | null | undefined, import("bn.js") | null | undefined, unknown>;
        accessList: t.Type<{
            address: Buffer;
            storageKeys: Buffer[] | null;
        }[] | undefined, {
            address: Buffer;
            storageKeys: Buffer[] | null;
        }[] | undefined, unknown>;
    }>>;
    number: t.Type<import("bn.js") | null, import("bn.js") | null, unknown>;
    hash: t.Type<Buffer | null, Buffer | null, unknown>;
    parentHash: t.Type<Buffer, Buffer, unknown>;
    nonce: t.Type<Buffer | undefined, Buffer | undefined, unknown>;
    sha3Uncles: t.Type<Buffer, Buffer, unknown>;
    logsBloom: t.Type<Buffer, Buffer, unknown>;
    transactionsRoot: t.Type<Buffer, Buffer, unknown>;
    stateRoot: t.Type<Buffer, Buffer, unknown>;
    receiptsRoot: t.Type<Buffer, Buffer, unknown>;
    miner: t.Type<Buffer, Buffer, unknown>;
    difficulty: t.Type<import("bn.js"), import("bn.js"), unknown>;
    totalDifficulty: t.Type<import("bn.js"), import("bn.js"), unknown>;
    extraData: t.Type<Buffer, Buffer, unknown>;
    size: t.Type<import("bn.js"), import("bn.js"), unknown>;
    gasLimit: t.Type<import("bn.js"), import("bn.js"), unknown>;
    gasUsed: t.Type<import("bn.js"), import("bn.js"), unknown>;
    timestamp: t.Type<import("bn.js"), import("bn.js"), unknown>;
    uncles: t.ArrayC<t.Type<Buffer, Buffer, unknown>>;
    mixHash: t.Type<Buffer | undefined, Buffer | undefined, unknown>;
}>;
//# sourceMappingURL=block.d.ts.map